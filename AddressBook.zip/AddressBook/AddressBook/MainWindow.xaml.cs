﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AddressBook
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Contact> contacts = new List<Contact>();
        public MainWindow()
        {
            InitializeComponent();
            contacts.Add(new Contact("Ivan", "948231","ivan@abv.bg"));
            contacts.Add(new Contact("Pesho", "9897342", "p334@abv.bg"));
            contacts.Add(new Contact("Monica", "8552312", "monica@hotmail.com"));
            contacts.Add(new Contact("Glen", "004442232", "glen@gmail.com"));
            contacts.Add(new Contact("Paul", "001233432", "paul@gmail.com"));
            lvwContacts.ItemsSource = contacts;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            
            contacts.Remove((Contact)lvwContacts.SelectedItem);
            
            
        }

        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            contacts.Add(new Contact("VESO", "001233432", "paul@gmail.com"));
            lvwContacts.ItemsSource = contacts;
        }


    }
}
